coco的个人博客，随缘更新。强制更新联系QQ：515638680
1.创建php数据库
2.修改mysql.php，填入数据库信息
3.导入php.sql文件
默认账户：admin
密码：admin